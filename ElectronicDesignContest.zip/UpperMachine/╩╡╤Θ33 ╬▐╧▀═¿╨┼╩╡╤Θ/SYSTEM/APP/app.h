#ifndef _app_h
#define _app_h
double abs(double Num);
#endif
