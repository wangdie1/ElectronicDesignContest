#include "app.h"
double abs(double Num)
{
	if (Num >= 0)
	{
	}
	else
	{
	  Num = -Num;
	}

	return Num;
}
