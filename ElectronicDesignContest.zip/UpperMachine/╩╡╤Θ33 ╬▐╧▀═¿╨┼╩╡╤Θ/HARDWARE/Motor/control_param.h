#ifndef control_param_h
#define control_param_h


// #define	RE20_SPEED_KP							3.4
// #define RE20_SPEED_KI							0.5
// #define RE20_SPEED_ERROR_BOND			1
// #define RE20_SPEED_MAX						360
// #define RE20_POSITION_KP					0.156
// #define RE20_POSITION_KI					0.00001
// #define RE20_POSITION_ERROR_BOND	5
// //#define RE20_POSITION_MAX					7200	


// #define	RE30_SPEED_KP							50
// #define RE30_SPEED_KI							0
// #define RE30_SPEED_ERROR_BOND			1
// #define RE30_POSITION_KP					0.3
// #define RE30_POSITION_KI					0
// #define RE30_POSITION_ERROR_BOND	5
// #define RE30_POSITION_MAX					1800


#endif

