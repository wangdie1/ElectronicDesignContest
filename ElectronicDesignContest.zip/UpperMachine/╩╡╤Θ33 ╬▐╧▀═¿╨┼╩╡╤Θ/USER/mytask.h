#ifndef __MYTASK_H
#define __MYTASK_H


//int MUSE_TASK(void);
//int KEY0_TASK(void);
//int KEY1_TASK(void);
//int KEY2_TASK(void);
//int KEY3_TASK(void);
//int KEY4_TASK(void);
//int KEY5_TASK(void);
//int KEY6_TASK(void);
//int KEY7_TASK(void);
//int KEY8_TASK(void);


int QJ_TASK(void); //ǰ��
int HT_TASK(void); //����
int ZZ_TASK(void); //��ת
int YZ_TASK(void); //��ת

#endif


