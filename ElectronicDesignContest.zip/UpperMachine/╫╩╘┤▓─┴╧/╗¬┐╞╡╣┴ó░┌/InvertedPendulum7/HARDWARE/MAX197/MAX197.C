#include "max197.h"
__IO vu16 MAX_ADC_Value0;
__IO vu16 MAX_ADC_Value1;
__IO vu16 MAX_ADC_Value2;
__IO vu16 MAX_ADC_Value3;

void MAX197_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph)
}
