#ifndef _max197_h
#define _max197_h

#include "stm32f10x.h"

#define  	MAX197_PORT 	GPIOC
#define 	MAX197_CS_Pin	GPIO_Pin_8
#define 	MAX197_WR_Pin	GPIO_Pin_9
#define 	MAX197_RD_Pin GPIO_Pin_10
#define 	MAX197_HBEN_Pin	GPIO_Pin_11
#define 	

#endif