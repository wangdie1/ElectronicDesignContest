#ifndef _extikey_h
#define _extikey_h
#include "stm32f10x.h"
#include "delay.h"

void EXTI_KEY_Init(void);
#endif