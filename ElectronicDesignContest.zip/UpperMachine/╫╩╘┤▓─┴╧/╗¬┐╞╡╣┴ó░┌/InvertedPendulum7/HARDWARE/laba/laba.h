#ifndef _laba_h
#define laba_h

void laba_init(void);
void laba_off();
void laba_on();
#endif