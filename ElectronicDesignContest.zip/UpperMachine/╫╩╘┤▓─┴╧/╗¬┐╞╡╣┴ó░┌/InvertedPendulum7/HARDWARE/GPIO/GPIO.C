#include "GPIO.h"
#include "stm32f10x.h"
void EnableGPIO_Init()
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 	
 RCC_APB2PeriphClockCmd(GPIO_PORT_CLK, ENABLE);	 //ʹ��PA�˿�ʱ��
	
 GPIO_InitStructure.GPIO_Pin = GPIO_PIN;				 //LED0-->PA.8 �˿�����
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 GPIO_Init(GPIO_PORT, &GPIO_InitStructure);
 GPIO_ResetBits(GPIO_PORT,GPIO_PIN);						 //PA.8 �����

}
void Disable(void)
{
	GPIO_ResetBits(GPIO_PORT,GPIO_PIN);
// 	GPIO_InitTypeDef  GPIO_InitStructure;
//  	
//  RCC_APB2PeriphClockCmd(GPIO_PORT_CLK, ENABLE);	 //ʹ��PA�˿�ʱ��
// 	
//  GPIO_InitStructure.GPIO_Pin = GPIO_PIN;				 //LED0-->PA.8 �˿�����
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; 		 //�������
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//  GPIO_Init(GPIO_PORT, &GPIO_InitStructure);
	
}
void Enable(void)
{
GPIO_SetBits(GPIO_PORT,GPIO_PIN);
// 	GPIO_InitTypeDef  GPIO_InitStructure;	
//   RCC_APB2PeriphClockCmd(GPIO_PORT_CLK, ENABLE);	 //ʹ��PA�˿�ʱ��
// 	
//  GPIO_InitStructure.GPIO_Pin = GPIO_PIN;				 //LED0-->PA.8 �˿�����
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//  GPIO_Init(GPIO_PORT, &GPIO_InitStructure);
// GPIO_ResetBits(GPIO_PORT,GPIO_PIN);
	
}