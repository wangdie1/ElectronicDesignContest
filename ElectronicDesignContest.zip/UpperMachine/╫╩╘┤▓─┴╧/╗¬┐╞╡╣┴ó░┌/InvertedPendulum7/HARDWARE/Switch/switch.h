#ifndef _switch_h
#define _switch_h
#include "stm32f10x.h"
extern __IO int is_ready;

void Switch_Init();
#endif