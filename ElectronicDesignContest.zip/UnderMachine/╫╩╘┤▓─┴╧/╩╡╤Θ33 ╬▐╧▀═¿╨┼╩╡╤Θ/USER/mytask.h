#ifndef _MyTask_h
#define _MyTaks_h

void MUSE_TASK();
void KEY0_TASK();
void KEY1_TASK();
void KEY2_TASK();
void KEY3_TASK();
void KEY4_TASK();
void KEY5_TASK();
void KEY6_TASK();
void KEY7_TASK();
void KEY8_TASK();


#endif