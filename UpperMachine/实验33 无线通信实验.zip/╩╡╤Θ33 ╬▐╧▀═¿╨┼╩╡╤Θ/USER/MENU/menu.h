#ifndef __MENU_H
#define __MENU_H


void MainMenu(void);
void StateMenu(void);
void TASTMenu(void);
void TAST1_Menu(void);
void TAST2_Menu(void);
void TAST3_Menu(void);


#endif


