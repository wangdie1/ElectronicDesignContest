#ifndef _app_h
#define _app_h
double abs_Double(double Num);
int abs_Int(int Num);
#endif
