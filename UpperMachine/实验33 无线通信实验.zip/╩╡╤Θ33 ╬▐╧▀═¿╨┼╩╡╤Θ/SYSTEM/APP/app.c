#include "app.h"
double abs_Double(double Num)
{
	if (Num >= 0)
	{
	}
	else
	{
	  Num = -Num;
	}

	return Num;
}
